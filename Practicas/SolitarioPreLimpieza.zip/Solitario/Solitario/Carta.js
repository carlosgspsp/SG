import * as THREE from '../libs/three.module.js'
import * as TWEEN from '../libs/tween.esm.js'
import { CSG } from '../libs/CSG-v2.js'

class Carta extends THREE.Object3D {
  constructor(imagen, numero, oculta = false) {
    super();

    // Se crea la parte de la interfaz que corresponde a la caja
    // Se crea primero porque otros métodos usan las variables que se definen para la interfaz
    //this.createGUI(gui,titleGui);


    this.numeroCarta = numero;
    this.cartaDebajo = null;
    this.cartaEncima = null;
    this.cartaOculta = oculta;
    this.cartaBloqueada = false;
    this.desfaseEjeZ = 3.5;
    this.desfaseEjeY = 0.1;

    var texturaDetras = new THREE.TextureLoader().load('../imgs/poker-card-back.jpg');
    var texturaDelante = new THREE.TextureLoader().load(imagen);
    //var material = new THREE.MeshPhongMaterial ({map: texture});
    var material = new THREE.MeshPhongMaterial({ color: "red" });


    var materiales = [new THREE.MeshPhongMaterial({ color: "white" }),
    new THREE.MeshPhongMaterial({ color: "white" }),
    new THREE.MeshPhongMaterial({ map: texturaDetras }),
    new THREE.MeshPhongMaterial({ map: texturaDelante }),
    new THREE.MeshPhongMaterial({ color: "white" }),
    new THREE.MeshPhongMaterial({ color: "white" })];

    //var material = new THREE.MeshNormalMaterial();
    material.flatShading = true;
    //var geometriaCaja = new THREE.BoxBufferGeometry (9,0.1,13);
    //var geometriaEsfera = new THREE.SphereGeometry( 7.5, 32, 16 );

    //var cajaMesh = new THREE.Mesh (geometriaCaja, materiales);
    //var esferaMesh = new THREE.Mesh (geometriaEsfera, materiales);

    //cartaCSG.union([cajaMesh]);
    //cartaCSG.intersect([esferaMesh]);

    //this.carta = cartaCSG.toMesh();

    var geometriaCaja = new THREE.BoxBufferGeometry(9, 0.01, 13);
    //geometriaCaja.rotateX(Math.PI);
    this.modeloCarta = new THREE.Mesh(geometriaCaja, materiales);
    this.modeloCarta.userData = this;
    // Y añadirlo como hijo del Object3D (el this)
    if (!oculta) {
      this.modeloCarta.rotation.x = Math.PI;
      //this.modeloCarta.geometry.rotateX(Math.PI);
    }
    this.modeloCarta.receiveShadow = true;
    this.modeloCarta.castShadow = true;

    //this.carta.rotation.z = Math.PI/2;
    //this.carta.rotation.y = Math.PI/2;
    this.add(this.modeloCarta);

    this.axis = new THREE.AxesHelper(5);
    this.add(this.axis);
    this.setAxisVisible(false);
    // Las geometrías se crean centradas en el origen.
    // Como queremos que el sistema de referencia esté en la base,
    // subimos el Mesh de la caja la mitad de su altura
    //box.position.y = 0.5;
    this.position.y = 1;

    this.crearLuces();
  }

  animacionMoverse(posicionNueva, velocidad) {


    var spline = new THREE.CatmullRomCurve3(
      [
        new THREE.Vector3(this.modeloCarta.position.x, this.modeloCarta.position.y + 2, this.modeloCarta.position.z),
        new THREE.Vector3(posicionNueva.x, posicionNueva.y, posicionNueva.z),
        //new THREE.Vector3(10,0,0),

      ], false
    );


    var origen = { p: 0 };
    var destino = { p: 1 };


    var animacion = new TWEEN.Tween(origen)
      .to(destino, velocidad) //tiempo que tarda la animacion en hacerse en ms
      .easing(TWEEN.Easing.Quadratic.InOut)
      .onUpdate(() => {
        var pos = spline.getPointAt(origen.p);
        this.modeloCarta.position.copy(pos);




      })
      .repeat(0) //veces que se repite, se hace 1 vez mas el numeo de repeticinoes
      .yoyo(false); //La animacion vuelve desde el punto final al punto de inicio si está a true

    animacion.start();
  }

  crearLuces(){
    // Se crea una luz ambiental, evita que se vean complentamente negras las zonas donde no incide de manera directa una fuente de luz
    // La luz ambiental solo tiene un color y una intensidad
    // Se declara como   var   y va a ser una variable local a este método
    //    se hace así puesto que no va a ser accedida desde otros métodos
    //var ambientLight = new THREE.AmbientLight(0xff0000, 0.7);
    // La añadimos a la escena
    //this.add(ambientLight);
    var posicionAjustada = new THREE.Vector3(this.modeloCarta.position.x, this.modeloCarta.position.y, this.modeloCarta.position.z)

    // add Light for the shadows
    this.Light = new THREE.SpotLight( 0xefb810, 0.9 ,0, Math.PI/6);
    this.Light.position.set(0, -7, 0);



    this.Light.target = this.modeloCarta;
    
    // the shadow resolution
    

    //this.Light.target.position.set(50,0,50);
    //this.Light.intensity = 1;
    //this.Light.shadow.bias = -0.0004;

    //var shadowCameraHelper = new THREE.CameraHelper(this.Light.shadow.camera);
    //shadowCameraHelper.visible = true;
    //this.add(shadowCameraHelper);

    //this.Light.shadow.mapSize.width = 2048
    //this.Light.shadow.mapSize.height = 2048;
    //this.add(this.Light);
    //this.add(this.Light.target);
    this.Light.visible = false;
    this.modeloCarta.add(this.Light);
    
  }

 /* crearLuces() {
    var width = 50;
    var height = 50;
    var intensity = 1;
    this.rectLight = new THREE.RectAreaLight(0xff0000, intensity, width, height);
    this.rectLight.position.set(0, 10, 0);
    this.rectLight.lookAt(0, 0, 0);
    this.add(this.rectLight)

    
    

  }*/

  update() {
    // Con independencia de cómo se escriban las 3 siguientes líneas, el orden en el que se aplican las transformaciones es:
    // Primero, el escalado
    // Segundo, la rotación en Z
    // Después, la rotación en Y
    // Luego, la rotación en X
    // Y por último la traslación
    //.guiControls.rotX += 0.01;
    //this.guiControls.rotZ += 0.01;
    //this.position.set (this.guiControls.posX,this.guiControls.posY,this.guiControls.posZ);
    //this.carta.rotation.set (this.guiControls.rotX,this.guiControls.rotY,this.guiControls.rotZ);

    //this.carta.scale.set (this.guiControls.sizeX,this.guiControls.sizeY,this.guiControls.sizeZ);

    TWEEN.update();

    if (this.cartaEncima == null && this.cartaOculta) {
      //console.log("entro al if este");
      this.girarCarta();
      this.cartaOculta = false;
    }

    

    /* if (this.escaleraCompleta()) {
       console.log("noseee");
     }*/

  }

  iluminarCartas(iluminar){

    this.Light.visible = iluminar;

    if (this.cartaEncima != null){
      this.cartaEncima.iluminarCartas(iluminar);
    }

  }

  /* escaleraCompleta() {
 
     var escalera = false;
     if (this.cartaDebajo != null && this.numeroCarta == 1) {
       var cartadebajo = this.cartaDebajo;
       escalera = true;
       for (var i = 0; i < 13 && this.cartadebajo != null; i++) {
         if (cartadebajo.numeroCarta != i + 1 || cartadebajo.cartaOculta) {
           escalera = false;
         }
         cartadebajo = cartadebajo.cartaDebajo;
       }
     }
 
     return escalera;
 
   }*/

  MoverCarta(posicionNueva) {
    var posicionNuevaAjustada = new THREE.Vector3(posicionNueva.x, posicionNueva.y + this.desfaseEjeY, posicionNueva.z + this.desfaseEjeZ);


    this.modeloCarta.position.x = posicionNuevaAjustada.x;
    this.modeloCarta.position.y = posicionNuevaAjustada.y;
    this.modeloCarta.position.z = posicionNuevaAjustada.z;





    if (this.cartaEncima != null) {
      this.cartaEncima.MoverCarta(new THREE.Vector3(posicionNuevaAjustada.x, posicionNuevaAjustada.y, posicionNuevaAjustada.z));
    }


  }

  MoverCartaConAnimacion(posicionNueva, velocidad = 100) {
    var posicionNuevaAjustada = new THREE.Vector3(posicionNueva.x, posicionNueva.y + 0.1, posicionNueva.z + this.desfaseEjeZ);

    /*
    this.modeloCarta.position.x = posicionNuevaAjustada.x;
    this.modeloCarta.position.y = posicionNuevaAjustada.y;
    this.modeloCarta.position.z = posicionNuevaAjustada.z;
    */


    //console.log("Voy a ejecutar la animacion");
    this.animacionMoverse(posicionNuevaAjustada, velocidad);
    if (this.cartaEncima != null) {
      this.cartaEncima.MoverCartaConAnimacion(new THREE.Vector3(posicionNuevaAjustada.x, posicionNuevaAjustada.y, posicionNuevaAjustada.z), velocidad);
    }


  }

  girarCarta() {


    //this.modeloCarta.rotation.x = Math.PI;

    var spline = new THREE.CatmullRomCurve3(
      [
        new THREE.Vector3(this.modeloCarta.position.x, 0, this.modeloCarta.position.z),
        new THREE.Vector3(this.modeloCarta.position.x, 5, this.modeloCarta.position.z),

      ], false
    );

    var origen1 = { p: 0 };
    var destino1 = { p: 1 };


    var origen2 = this.modeloCarta.rotation;
    var destino2 = { x: (Math.PI) };

    var origen3 = { p: 1 };
    var destino3 = { p: 0.1 };


    var animacion1 = new TWEEN.Tween(origen1)
      .to(destino1, 300) //tiempo que tarda la animacion en hacerse en ms
      .easing(TWEEN.Easing.Quadratic.Out)
      .onUpdate(() => {
        var pos = spline.getPointAt(origen1.p);
        this.modeloCarta.position.copy(pos);



      })
      .repeat(0) //veces que se repite, se hace 1 vez mas el numeo de repeticinoes
      .yoyo(false); //La animacion vuelve desde el punto final al punto de inicio si está a true


    var animacion2 = new TWEEN.Tween(origen2)
      .to(destino2, 300) //tiempo que tarda la animacion en hacerse en ms
      .easing(TWEEN.Easing.Quadratic.InOut)
      .onStart(() => {
        //this.modeloCarta.position.y+=2;

      })
      .onComplete(() => {
        //this.modeloCarta.position.y-=2;

      })
      .repeat(0) //veces que se repite, se hace 1 vez mas el numeo de repeticinoes
      .yoyo(false); //La animacion vuelve desde el punto final al punto de inicio si está a true


    var animacion3 = new TWEEN.Tween(origen3)
      .to(destino3, 300) //tiempo que tarda la animacion en hacerse en ms
      .easing(TWEEN.Easing.Quadratic.In)
      .onUpdate(() => {
        var pos = spline.getPointAt(origen3.p);
        this.modeloCarta.position.copy(pos);


      })
      .repeat(0) //veces que se repite, se hace 1 vez mas el numeo de repeticinoes
      .yoyo(false); //La animacion vuelve desde el punto final al punto de inicio si está a true

    animacion1.chain(animacion2);
    animacion2.chain(animacion3);
    animacion1.start();



  }

  bloquearCartas() {
    var cartaAux = this;

    //console.log("Numero carta: " + cartaAux.numeroCarta);
    //console.log("Numero carta debajo: " + cartaAux.cartaDebajo.numeroCarta);
    //console.log("Segunda condicion: " + (cartaAux.numeroCarta != (cartaAux.cartaDebajo.numeroCarta - 1)));
    //console.log("Tercera condicion: " + !cartaAux.cartaOculta);
    //console.log("-------------");


    if (cartaAux.cartaDebajo != null && (cartaAux.numeroCarta != (cartaAux.cartaDebajo.numeroCarta - 1)) && !cartaAux.cartaOculta) {


      while (cartaAux.cartaDebajo != null) {
        cartaAux = cartaAux.cartaDebajo;
        cartaAux.cartaBloqueada = true;
      }
    }

  }

  desbloquearCartas() {
    //var carta = this.ultimaCartaSeleccionada;
    // carta = this.getCartaMasArriba(carta);
    //console.log("Hola estoy desbloqueando");
    var cartaAux = this;
    
    while ((cartaAux.cartaDebajo != null) && (cartaAux.numeroCarta == (cartaAux.cartaDebajo.numeroCarta - 1)) && !cartaAux.cartaDebajo.cartaOculta) {
      
      cartaAux.cartaBloqueada = false;
      cartaAux = cartaAux.cartaDebajo;
    }
    
    cartaAux.cartaBloqueada = false;
    
  }


  setAxisVisible(valor) {
    this.axis.visible = valor;
  }

}

export { Carta };
